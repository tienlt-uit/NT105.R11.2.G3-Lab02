import numpy as np
import matplotlib.pyplot as plt

f = 50
T = 1 / f
omega = 2 * np.pi * f

t = np.linspace(0, 2 * T, 1000)

s1 = np.sin(omega * t + np.radians(0))
s2 = np.sin(omega * t + np.radians(90))
s3 = np.sin(omega * t + np.radians(180))
s4 = np.sin(omega * t + np.radians(270))

plt.figure(figsize=(10, 6))
plt.plot(t * 1000, s1, label=r'$s_1(t): \phi = 0^\circ$', color='blue', linewidth=2)
plt.plot(t * 1000, s2, label=r'$s_2(t): \phi = 90^\circ$', color='orange', linewidth=2)
plt.plot(t * 1000, s3, label=r'$s_3(t): \phi = 180^\circ$', color='green', linewidth=2, linestyle='--')
plt.plot(t * 1000, s4, label=r'$s_4(t): \phi = 270^\circ$', color='red', linewidth=2, linestyle='--')

plt.title('Đồ thị 4 sóng sin (f = 50 Hz, A = 1.0) với các pha ban đầu khác nhau', fontsize=12)
plt.xlabel('Thời gian t (ms)', fontsize=11)
plt.ylabel('Biên độ', fontsize=11)
plt.axhline(0, color='black', linewidth=0.8, linestyle=':')
plt.grid(True, linestyle='--', alpha=0.7)
plt.legend(loc='upper right', fontsize=10)

t_ticks = np.array([0, T/4, T/2, 3*T/4, T]) * 1000
plt.xticks(np.arange(0, 41, 5))

plt.tight_layout()
plt.savefig('four_sine_waves.png', dpi=300)
print("Plot saved as four_sine_waves.png")