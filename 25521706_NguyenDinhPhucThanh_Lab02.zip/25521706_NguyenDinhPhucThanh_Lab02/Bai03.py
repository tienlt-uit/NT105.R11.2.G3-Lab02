import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

fs = 100000
f0 = 100
t_duration = 0.1
N = int(fs * t_duration)
t = np.linspace(0, t_duration, N, endpoint=False)

duty_cycles = [0.20, 0.50, 0.80]
colors = ['blue', 'orange', 'green']

fig, axes = plt.subplots(3, 2, figsize=(12, 9))

results = []

for i, duty in enumerate(duty_cycles):
    sq_wave = (signal.square(2 * np.pi * f0 * t, duty=duty) + 1) / 2
    
    high_samples = np.sum(sq_wave > 0.5)
    percentage_high = (high_samples / N) * 100
    
    mean_val = np.mean(sq_wave)
    
    fft_vals = np.fft.rfft(sq_wave)
    fft_freqs = np.fft.rfftfreq(N, 1/fs)
    
    fft_mag = np.abs(fft_vals) / N
    fft_mag_onesided = fft_mag.copy()
    fft_mag_onesided[1:] = 2 * fft_mag_onesided[1:]
    
    results.append({
        'duty': duty * 100,
        'percentage_high': percentage_high,
        'mean_val': mean_val,
        'dc_fft_raw_mag': fft_mag[0],
        'dc_fft_val_real': np.real(fft_vals[0]) / N
    })
    
    axes[i, 0].plot(t[:3000] * 1000, sq_wave[:3000], color=colors[i], linewidth=1.5)
    axes[i, 0].set_title(f'Sóng vuông {f0} Hz - Duty Cycle {int(duty*100)}% (Miền thời gian)')
    axes[i, 0].set_xlabel('Thời gian (ms)')
    axes[i, 0].set_ylabel('Biên độ (V)')
    axes[i, 0].set_ylim(-0.2, 1.2)
    axes[i, 0].grid(True)
    
    mask = fft_freqs <= 1000
    axes[i, 1].stem(fft_freqs[mask], fft_mag[mask], linefmt=colors[i], markerfmt='o', basefmt=" ")
    axes[i, 1].set_title(f'Phổ một bên (rfft) - Duty Cycle {int(duty*100)}%')
    axes[i, 1].set_xlabel('Tần số (Hz)')
    axes[i, 1].set_ylabel('Biên độ chuẩn hóa |X(f)|/N')
    axes[i, 1].grid(True)
    
    axes[i, 1].annotate(f'DC (0 Hz) = {fft_mag[0]:.2f} V',
                        xy=(0, fft_mag[0]), xytext=(150, fft_mag[0] + 0.1),
                        arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=6))
    axes[i, 1].set_ylim(0, 1.0)

plt.tight_layout()
plt.savefig('square_waves_analysis.png', dpi=300)
print("Results summary:", results)