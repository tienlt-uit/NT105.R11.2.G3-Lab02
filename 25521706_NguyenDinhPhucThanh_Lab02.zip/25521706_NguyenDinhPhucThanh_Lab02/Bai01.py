import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

fig, axs = plt.subplots(3, 1, figsize=(10, 8))
plt.subplots_adjust(hspace=0.5)

rng = np.random.default_rng(0)
fs = 1000
t = np.linspace(0, 1, fs, endpoint=False)
analog_signal = 4 + 0.5 * np.sin(2 * np.pi * 3 * t) + 0.1 * rng.standard_normal(len(t))

axs[0].plot(t, analog_signal, 'b')
axs[0].set_title('1. Tin hieu tuong tu (4 + 0.5*sin(2pi*3t) co nhieu)')
axs[0].set_xlabel('Thoi gian (s)')
axs[0].set_ylabel('Bien do (V)')
axs[0].set_ylim(0, 6)
axs[0].grid(True)

bits = np.array([1, 1, 0, 1, 0, 0, 1, 0])
samples_per_bit = 50
digital_signal = np.repeat(bits, samples_per_bit)
n = np.arange(len(digital_signal))

axs[1].step(n, digital_signal, 'r', where='post')
axs[1].set_title('2. Tin hieu so (Chuoi bit: 1 1 0 1 0 0 1 0)')
axs[1].set_xlabel('Mau (n)')
axs[1].set_ylabel('Bien do')
axs[1].set_ylim(-0.2, 1.2)
axs[1].grid(True)

f_sawtooth = 25
sawtooth_signal = signal.sawtooth(2 * np.pi * f_sawtooth * t)

axs[2].plot(t, sawtooth_signal, 'g')
axs[2].set_title('3. Tin hieu song rang cua (25 Hz)')
axs[2].set_xlabel('Thoi gian (s)')
axs[2].set_ylabel('Bien do')
axs[2].grid(True)

plt.savefig('signals_plot.png')
print("Plot saved to signals_plot.png")
plt.show()