import numpy as np
import matplotlib.pyplot as plt

f0, fs = 50.0, 10000.0 
t = np.arange(0, 0.04, 1 / fs) 

def square_synth(t, amplitude, f0, k_max):
    out = np.zeros_like(t)
    for k in range(1, k_max + 1, 2):
        out += np.sin(2 * np.pi * k * f0 * t) / k
    return amplitude * (4 / np.pi) * out

k_values = [1, 3, 9, 25]
fig, axes = plt.subplots(4, 1, figsize=(9, 8), sharex=True)

for ax, k_max in zip(axes, k_values):
    s = square_synth(t, 1.0, f0, k_max)
    ax.plot(t, s, 'b-', label=f'k_max = {k_max}')
    ax.set_title(f"k_max = {k_max}", fontsize=10)
    ax.set_ylim(-1.5, 1.5)
    ax.grid(True)
    ax.axhline(1.0, color='r', linestyle='--', alpha=0.5)
    ax.axhline(-1.0, color='r', linestyle='--', alpha=0.5)

axes[-1].set_xlabel("Thời gian (s)")
fig.suptitle("Tổng hợp sóng vuông từ các sóng hài (k_max = 1, 3, 9, 25)", fontsize=12)
fig.tight_layout()
fig.savefig("square_synth_k1_3_9_25.png", dpi=300)
plt.close(fig)

t_dense = np.linspace(0, 0.04, 100000)
A_ideal = 1.0

overshoot_data = []
for k_max in k_values:
    s_dense = square_synth(t_dense, A_ideal, f0, k_max)
    max_val = np.max(s_dense)
    overshoot_v = max_val - A_ideal
    overshoot_pct = (overshoot_v / A_ideal) * 100
    overshoot_data.append((k_max, max_val, overshoot_v, overshoot_pct))

print("K_MAX | MAX_VAL | OVERSHOOT (V) | OVERSHOOT (%)")
for row in overshoot_data:
    print(f"{row[0]:5d} | {row[1]:7.4f} | {row[2]:13.4f} | {row[3]:12.2f}%")

k_valid = 99
k_exceed = 201

s_99 = square_synth(t, 1.0, f0, k_valid)
s_105 = square_synth(t, 1.0, f0, k_exceed)

fig2, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6), sharex=True)

ax1.plot(t, s_99, 'g-')
ax1.set_title(f"Sóng tổng hợp chuẩn Nyquist (k_max = {k_valid}, f_max = {k_valid*f0} Hz < fs/2 = 5000 Hz)")
ax1.set_ylim(-1.5, 1.5)
ax1.grid(True)

ax2.plot(t, s_105, 'r-')
ax2.set_title(f"Sóng tổng hợp Vi phạm Nyquist (k_max = {k_exceed}, f_max = {k_exceed*f0} Hz > fs/2 = 5000 Hz)")
ax2.set_ylim(-1.5, 1.5)
ax2.grid(True)
ax2.set_xlabel("Thời gian (s)")

fig2.tight_layout()
fig2.savefig("nyquist_violation.png", dpi=300)
plt.close(fig2)