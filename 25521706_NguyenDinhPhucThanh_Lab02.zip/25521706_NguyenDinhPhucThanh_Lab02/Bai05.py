import numpy as np
import matplotlib.pyplot as plt

c = 3e8
fHz = 2.4e9
wavelength = c / fHz
d = np.linspace(1, 5000, 5000)
FSL_dB = 20 * np.log10(4 * np.pi * d / wavelength)
P_phat = 20

P_thu_0_0 = P_phat + 0 + 0 - FSL_dB
P_thu_6_6 = P_phat + 6 + 6 - FSL_dB
P_thu_12_12 = P_phat + 12 + 12 - FSL_dB

fig, ax1 = plt.subplots(figsize=(12, 7))

color1 = 'tab:red'
ax1.set_xlabel('Khoảng cách d (m)', fontsize=12)
ax1.set_ylabel('Suy hao FSL (dB)', color=color1, fontsize=12)
line1 = ax1.plot(d, FSL_dB, color=color1, linestyle='--', linewidth=2, label='Suy hao FSL (dB)')
ax1.tick_params(axis='y', labelcolor=color1)
ax1.grid(True, linestyle=':', alpha=0.7)

ax2 = ax1.twinx()  
color2 = 'black'
ax2.set_ylabel('Công suất thu $P_{thu}$ (dBm)', color=color2, fontsize=12)  
line2 = ax2.plot(d, P_thu_0_0, color='tab:blue', linewidth=2, label='$P_{thu}$ với G=(0,0) dBi')
line3 = ax2.plot(d, P_thu_6_6, color='tab:green', linewidth=2, label='$P_{thu}$ với G=(6,6) dBi')
line4 = ax2.plot(d, P_thu_12_12, color='tab:purple', linewidth=2, label='$P_{thu}$ với G=(12,12) dBi')
ax2.tick_params(axis='y', labelcolor=color2)

lines = line1 + line2 + line3 + line4
labels = [l.get_label() for l in lines]
ax1.legend(lines, labels, loc='center right', fontsize=11, bbox_to_anchor=(0.98, 0.5))

plt.title('Suy hao FSL và Công suất thu (Friis) theo khoảng cách tại 2.4 GHz', fontsize=14, fontweight='bold')
plt.tight_layout()

plt.savefig('friis_fsl_plot.png', dpi=300)
print("Plot saved.")